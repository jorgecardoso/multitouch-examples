#!/bin/sh

java -jar target/touchtokensTUIO-0.0.1-SNAPSHOT.jar "$@"
