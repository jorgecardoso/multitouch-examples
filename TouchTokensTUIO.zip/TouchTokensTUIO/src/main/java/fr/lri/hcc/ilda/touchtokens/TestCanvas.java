package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2015. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JPanel;

public class TestCanvas extends JPanel implements TokenListener {

	private static final long serialVersionUID = 3031935397961635020L;

	protected static double SCREEN_RES = -1; // px.mm-1

	protected TokenEvent event = null;
	protected String tokenID = null;

	private Font font = new Font("Arial", Font.PLAIN, 60);

	public TestCanvas(int width, int height) {
		super();
		setPreferredSize(new Dimension(width, height));
		int pixelsPerInch = Toolkit.getDefaultToolkit().getScreenResolution();
		SCREEN_RES = pixelsPerInch/25.4; // pixels per mm
	}

	public void tokenDown(TokenEvent event) {
		tokenID = event.getTokenID();
		this.event = event;
		repaint();
	}

	public void tokenMoved(TokenEvent event) {
		this.event = event;
		repaint();
	}

	public void tokenUp(TokenEvent event) {
		tokenID = null;
		this.event = event;
		repaint();
	}


	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(tokenID == null) {
			return;
		}
		Graphics2D g2d = (Graphics2D)g;
		RenderingHints rh = new RenderingHints(
				RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);
		ArrayList<TouchPoint> pts = new ArrayList<TouchPoint>();
		for (Iterator<TouchPoint> iterator = event.getPoints().iterator(); iterator.hasNext();) {
			TouchPoint touchPoint = iterator.next();
			if(touchPoint != null) {
				pts.add(touchPoint);
			}
		}
		TouchPoint centroid = TouchTokenRecognizer.centroid(pts);
		g2d.setColor(Color.GREEN);
		g2d.fillOval((int)(centroid.x * getWidth() - 10), (int)(centroid.y * getHeight() - 10), 20, 20);
		g2d.setColor(Color.LIGHT_GRAY);
		for (Iterator<TouchPoint> iterator = pts.iterator(); iterator.hasNext();) {
			TouchPoint point = iterator.next();
			double dx = point.x - centroid.x;
			double dy = point.y - centroid.y;
			double dxInMM = dx * event.getDeviceWidth();
			double dyInMM = dy * event.getDeviceHeight();
			double dxInWindow = dxInMM * SCREEN_RES;
			double dyInWindow = dyInMM * SCREEN_RES;
			g2d.fillOval((int)(centroid.x * getWidth() + dxInWindow - 10), (int)(centroid.y * getHeight() + dyInWindow - 10), 20, 20);
		}

		g2d.setColor(Color.BLACK);
		setFont(font);
		FontMetrics fm = g.getFontMetrics();
		String textTokenID = tokenID;
		String textLocation = "("+(int)(centroid.x * getWidth())+", "+(int)(centroid.y * getHeight())+")";
		Rectangle2D boundsTextTokenID = fm.getStringBounds(textTokenID, g);
		Rectangle2D boundsTextLocation = fm.getStringBounds(textLocation, g);
		g2d.drawString(textTokenID, 10, (int)(getHeight() - 10 - boundsTextLocation.getHeight() - 10 - boundsTextTokenID.getHeight()));
		g2d.drawString(textLocation, 10, (int)(getHeight() - 10 - boundsTextLocation.getHeight()));
	}

}
