package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2015. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.util.ArrayList;

public class TokenTemplate extends MultiTouchInput {

	protected String tokenID;
	protected double distance;

	public TokenTemplate(ArrayList<TouchPoint> points, String tokenID) {
		super(points);
		this.points = points;
		this.tokenID = tokenID;
	}

	public String toString() {
		String points = "";
		for (TouchPoint pt : this.points) {
			points += "("+pt.getX()+","+pt.getY()+")";
		}
		points += "";
		return tokenID+" ["+points+"]";
	}

	public ArrayList<TouchPoint> getPoints() {
		return points;
	}

	public void setPoints(ArrayList<TouchPoint> points) {
		this.points = points;
	}

	public String getTokenID() {
		return tokenID;
	}

	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

}
