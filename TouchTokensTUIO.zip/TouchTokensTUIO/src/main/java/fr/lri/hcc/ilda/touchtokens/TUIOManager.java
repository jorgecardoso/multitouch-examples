package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2015. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.Timer;

import TUIO.TuioClient;
import TUIO.TuioCursor;
import TUIO.TuioListener;
import TUIO.TuioObject;
import TUIO.TuioTime;

public class TUIOManager implements TuioListener, ActionListener {

	protected TouchTokenRecognizer recognizer;
	protected String tokenDown = null;
	protected ArrayList<TokenListener> listeners;

	protected double inputWidth = -1;
	protected double inputHeight = -1;

	protected static TouchPoint[] FINGERS_LOCATION = new TouchPoint[10];
	protected static TouchPoint[] FINGERS_LOCATION_AT_TIMER_START_TIME = new TouchPoint[10];

	protected int dwellDuration = 200; // in ms
	protected double dwellTolerance = 3; // in mm

	protected Timer dwellTimer;
	protected long dwellStartTime = -1;
	protected long lastUpdateTime = -1;

	protected boolean debug = false;

	protected ArrayList<Integer> indices = new ArrayList<Integer>();

	public TUIOManager(TouchTokenRecognizer recognizer, int tuioPort, double inputWidth, double inputHeight) {
		this.recognizer = recognizer;
		this.inputWidth = inputWidth;
		this.inputHeight = inputHeight;

		listeners = new ArrayList<TokenListener>();

		dwellTimer = new Timer(25, this);
		dwellTimer.setRepeats(true);
		dwellTimer.start();

		TuioClient tuioClient = new TuioClient(tuioPort);
		if(tuioClient != null) tuioClient.addTuioListener(this);
		tuioClient.connect();
	}

	public void addTokenListener(TokenListener listener) {
		listeners.add(listener);
	}

	public void removeTokenListener(TokenListener listener) {
		listeners.remove(listener);
	}

	protected void fireTokenDown(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight) {
		TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, deviceWidth, deviceHeight);
		for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
			TokenListener tokenListener = iterator.next();
			tokenListener.tokenDown(tokenEvent);
		}
	}

	protected void fireTokenMoved(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight) {
		TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, deviceWidth, deviceHeight);
		for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
			TokenListener tokenListener = iterator.next();
			tokenListener.tokenMoved(tokenEvent);
		}
	}

	protected void fireTokenUp(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight) {
		TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, deviceWidth, deviceHeight);
		for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
			TokenListener tokenListener = iterator.next();
			tokenListener.tokenUp(tokenEvent);
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dwellTimer) {
			if(dwellStartTime == -1) {
				return;
			}
			if(tokenDown != null) {
				return;
			}
			long currentTime = System.currentTimeMillis();
			if((currentTime - dwellStartTime) >= dwellDuration && (lastUpdateTime - dwellStartTime) < dwellDuration) {
				ArrayList<TouchPoint> inputInMms = new ArrayList<TouchPoint>(); // the recognizer stores templates in mm
				ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
				indices.clear();
				for (int i = 0; i < FINGERS_LOCATION.length; i++) {
					if(FINGERS_LOCATION[i] != null) {
						indices.add(i);
						inputInMms.add(new TouchPoint(FINGERS_LOCATION[i].x * inputWidth, FINGERS_LOCATION[i].y * inputHeight));
						inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
					}
				}
				if(debug) {
					System.out.println("input: "+inputInMms);
				}
				TokenTemplate tt = recognizer.recognize(inputInMms);
				if(debug) {
					System.out.println("recognized as: "+tt);
				}
				if(tt != null) {
					tokenDown = tt.getTokenID();
					fireTokenDown(tokenDown, inputIn01, inputWidth, inputHeight);
				}
			}
			lastUpdateTime = System.currentTimeMillis();
		}
	}

	public void addTuioObject(TuioObject arg0) { }

	public void removeTuioObject(TuioObject arg0) { }

	public void updateTuioObject(TuioObject arg0) { }

	public void refresh(TuioTime arg0) { }

	public void addTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();
		FINGERS_LOCATION[cursorID] = new TouchPoint(arg0.getX(), arg0.getY());
		if(debug) {
			System.out.println("+ tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
		}
		dwellStartTime = System.currentTimeMillis();
	}

	public void removeTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();
		int fingerCount = 0;
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			if(FINGERS_LOCATION[i] != null) {
				fingerCount++;
			}
		}
		if(fingerCount == 1) {
			dwellStartTime = -1;
			ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
			for (int i = 0; i < FINGERS_LOCATION.length; i++) {
				if(FINGERS_LOCATION[i] != null) {
					inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
				} else if(indices.contains(i)) {
					inputIn01.add(null);
				}
			}
			fireTokenUp(tokenDown, inputIn01, inputWidth, inputHeight);
			tokenDown = null;
		} else {
			dwellStartTime = System.currentTimeMillis();
		}
		FINGERS_LOCATION[cursorID] = null;
		if(debug) {
			System.out.println("- tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
		}
	}

	public void updateTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();

		FINGERS_LOCATION[cursorID] = new TouchPoint(arg0.getX(), arg0.getY());

		if(debug) {
			System.out.println("~ tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}

		// sometimes, MT events are not delivered in the right order, avoid null exception:
		if(FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID] == null) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID] = FINGERS_LOCATION[cursorID];
		}

		TouchPoint pointNow = new TouchPoint(FINGERS_LOCATION[cursorID].x * inputWidth, FINGERS_LOCATION[cursorID].y * inputHeight);
		TouchPoint pointAtTimerStartTime = new TouchPoint(FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID].x * inputWidth, FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID].y * inputHeight);

		double distance = pointNow.distance(pointAtTimerStartTime);

		boolean dwelling = distance < dwellTolerance;
		if(!dwelling) {
			for (int i = 0; i < FINGERS_LOCATION.length; i++) {
				FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
			}
			dwellStartTime = System.currentTimeMillis();
		}

		ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			if(FINGERS_LOCATION[i] != null) {
				inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
			} else if(indices.contains(i)) {
				inputIn01.add(null);
			}
		}
		if(tokenDown != null) {
			fireTokenMoved(tokenDown, inputIn01, inputWidth, inputHeight);
		}
	}

	public int getDwellDuration() {
		return dwellDuration;
	}

	public void setDwellDuration(int dwellDuration) {
		this.dwellDuration = dwellDuration;
	}

	public double getDwellTolerance() {
		return dwellTolerance;
	}

	public void setDwellTolerance(double dwellTolerance) {
		this.dwellTolerance = dwellTolerance;
	}

}
