package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2015. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;


public class TouchTokenRecognizer {

	protected ArrayList<TokenTemplate> tokenTemplates;

	public TouchTokenRecognizer(File templatesFile) {
		this.tokenTemplates = new ArrayList<TokenTemplate>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(templatesFile));
			String line = br.readLine();
//			NumberFormat format = NumberFormat.getInstance(Locale.US);
			DecimalFormat df = new DecimalFormat();
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator('.');
			symbols.setGroupingSeparator(',');
			df.setDecimalFormatSymbols(symbols);
			while (line != null) {
//				System.out.println(line);
				if (!line.startsWith("#")) {
					String[] parts = line.split(",");
					if (parts.length > 3) {
						String tokenID = parts[0];
						int fingerCount = Integer.parseInt(parts[1]);
						ArrayList<TouchPoint> points = new ArrayList<TouchPoint>();
						for (int i = 0; i < fingerCount; i++) {
							double x = df.parse(parts[2+(i*2)]).doubleValue();
							double y = df.parse(parts[2+(i*2)+1]).doubleValue();
							TouchPoint point = new TouchPoint(x, y);
							points.add(point);
						}
						TokenTemplate tt = new TokenTemplate(points, tokenID);
//						System.out.println(tt);
						tokenTemplates.add(tt);
					}
				}
				line = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}

	public static void centerOnPoint(ArrayList<TouchPoint> points, TouchPoint refPoint) {
		for (TouchPoint pt : points) {
			pt.setLocation(pt.getX() - refPoint.getX(), pt.getY() - refPoint.getY());
		}
	}

	public static double angleBetweenVectors(TouchPoint vector1, TouchPoint vector2) {
		double angle = Math.atan2(vector2.getY(), vector2.getX()) - Math.atan2(vector1.getY(), vector1.getX());
		//	normalize to the range 0 .. 2 * Pi:
		if (angle < 0) angle += 2 * Math.PI;
		return angle;
	}

	public static void orderCCW(ArrayList<TouchPoint> points, final TouchPoint refPoint) {
		final TouchPoint vectorXAxis = new TouchPoint(10, 0);
		Collections.sort(points, new Comparator<TouchPoint>() {
			public int compare(TouchPoint pt1, TouchPoint pt2) {
				TouchPoint vector1 = new TouchPoint(pt1.getX() - refPoint.getX(), pt1.getY() - refPoint.getY());
				double angle1 = angleBetweenVectors(vectorXAxis, vector1);
				TouchPoint vector2 = new TouchPoint(pt2.getX() - refPoint.getX(), pt2.getY() - refPoint.getY());
				double angle2 = angleBetweenVectors(vectorXAxis, vector2);
				return (int)((angle2 - angle1)*100);
			}
		});
	}

	public static void rotateBy(ArrayList<TouchPoint> points, TouchPoint refPoint, double theta, ArrayList<TouchPoint> newPoints) {
		TouchPoint ptSrc, ptDest;
		for (int i = 0; i < points.size(); i++) {
			ptSrc = points.get(i);
			if (newPoints.size() > i) {
				ptDest = newPoints.get(i);
			} else {
				ptDest = new TouchPoint();
				newPoints.add(i, ptDest);
			}
			double x = (ptSrc.getX() - refPoint.getX()) * Math.cos(theta) - (ptSrc.getY() - refPoint.getY()) * Math.sin(theta) + refPoint.getX();
			double y = (ptSrc.getX() - refPoint.getX()) * Math.sin(theta) + (ptSrc.getY() - refPoint.getY()) * Math.cos(theta) + refPoint.getY();
			ptDest.setLocation(x, y);
		}
	}

	public static ArrayList<TouchPoint> orderAndAlign(ArrayList<TouchPoint> points, TouchPoint refPoint) {
		ArrayList<TouchPoint> resPoints = new ArrayList<TouchPoint>();
		for (TouchPoint pt : points) {
			resPoints.add(new TouchPoint(pt.getX(), pt.getY()));
		}
		centerOnPoint(resPoints, refPoint);
		TouchPoint origin = new TouchPoint(0, 0);
		orderCCW(resPoints, origin);
		TouchPoint refVector = new TouchPoint(resPoints.get(0).getX(), resPoints.get(0).getY());
		TouchPoint xAxisVector = new TouchPoint(10, 0);
		double angle = angleBetweenVectors(refVector, xAxisVector);
		rotateBy(resPoints, origin, angle, resPoints);
		return resPoints;
	}

	public static TouchPoint centroid(ArrayList<TouchPoint> points) {
		double sumX = 0;
		double sumY = 0;
		for (Iterator<TouchPoint> iterator = points.iterator(); iterator.hasNext();) {
			TouchPoint next = iterator.next();
			sumX += next.getX();
			sumY += next.getY();
		}
		int length = points.size();
		return new TouchPoint(sumX / length, sumY / length);
	}

	public static ArrayList<ArrayList<TouchPoint>> allPermutations(ArrayList<TouchPoint> points) {
		ArrayList<ArrayList<TouchPoint>> allPermutations = new ArrayList<ArrayList<TouchPoint>>();
		for (int i = 0; i < points.size(); i++) {
			ArrayList<TouchPoint> order = new ArrayList<TouchPoint>();
			order.add(points.get(i));
			for(int j = i+1; j < points.size(); j++) {
				order.add(points.get(j));
			}
			for(int j = 0; j < i; j++) {
				order.add(points.get(j));
			}
			allPermutations.add(order);
		}
		return allPermutations;
	}

	public static double meanSquaredPairedPointDistanceForAlignedPairs(ArrayList<TouchPoint> points1, ArrayList<TouchPoint> points2) {
		if(points1.size() != points2.size()) {
			return Double.MAX_VALUE;
		} else {
			double res = 0;
			for (int i = 0; i < points1.size(); i++) {
				TouchPoint p1 = points1.get(i);
				TouchPoint p2 = points2.get(i);
				res += (p1.getX() - p2.getX()) * (p1.getX() - p2.getX()) + (p1.getY() - p2.getY()) * (p1.getY() - p2.getY());
			}
			return res / points1.size();
		}
	}

	public static double minDistance(ArrayList<TouchPoint> templatePointsOrderedAndAligned, ArrayList<TouchPoint> inputPoints, TouchPoint refPoint) {
		ArrayList<TouchPoint> inputPointsOrderedAndAligned = orderAndAlign(inputPoints, refPoint);
		ArrayList<ArrayList<TouchPoint>> allPermutations = allPermutations(inputPointsOrderedAndAligned);
		double minDis = Double.MAX_VALUE;
		for (ArrayList<TouchPoint> inputPermutation : allPermutations) {
			TouchPoint origin = new TouchPoint(0, 0);
			TouchPoint refVector = new TouchPoint(inputPermutation.get(0).getX(), inputPermutation.get(0).getY());
			TouchPoint xAxisVector = new TouchPoint(10, 0);
			double angle = angleBetweenVectors(refVector, xAxisVector);
			ArrayList<TouchPoint> inputPermutationRotated = new ArrayList<TouchPoint>();
			rotateBy(inputPermutation, origin, angle, inputPermutationRotated);
			double d = meanSquaredPairedPointDistanceForAlignedPairs(inputPermutationRotated, templatePointsOrderedAndAligned);
			if(d < minDis) {
				minDis = d;
			}
		}
		return minDis;
	}

	public TokenTemplate recognize(ArrayList<TouchPoint> input) {
		for (TokenTemplate tokenTemplate : tokenTemplates) {
			tokenTemplate.setDistance(Double.MAX_VALUE);
		}

		double minDis = Double.MAX_VALUE;
		TokenTemplate tokenRecognized = null;
		for (TokenTemplate tokenTemplate : tokenTemplates) {
			ArrayList<TouchPoint> templatePoints = orderAndAlign(tokenTemplate.getPoints(), centroid(tokenTemplate.getPoints()));
			double d = minDistance(templatePoints, input, centroid(input));
			tokenTemplate.setDistance(d);
//			System.out.println("\t--> distance to "+tokenTemplate+" is "+tokenTemplate.distance);
			if(d < minDis) {
				minDis = d;
				tokenRecognized = tokenTemplate;
			}
		}
		return tokenRecognized;
	}

	public static void main(String[] args) {
		new TouchTokenRecognizer(new File("templates/templates.txt"));
	}

}
