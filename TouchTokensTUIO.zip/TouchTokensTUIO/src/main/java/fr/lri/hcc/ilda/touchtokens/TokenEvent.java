package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2015. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.util.ArrayList;
import java.util.EventObject;

public class TokenEvent extends EventObject {

	private static final long serialVersionUID = 3067543063371826506L;

	protected String tokenID;

	protected ArrayList<TouchPoint> points; // normalized in [0,1]

	protected double deviceWidth; // size of the physical input surface in mm
	protected double deviceHeight;

	public TokenEvent(Object source) {
		super(source);
	}


	public TokenEvent(Object source, String tokenID,
			ArrayList<TouchPoint> points, double deviceWidth,
			double deviceHeight) {
		super(source);
		this.tokenID = tokenID;
		this.points = points;
		this.deviceWidth = deviceWidth;
		this.deviceHeight = deviceHeight;
	}


	public String getTokenID() {
		return tokenID;
	}

	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}

	public ArrayList<TouchPoint> getPoints() {
		return points;
	}


	public void setPoints(ArrayList<TouchPoint> points) {
		this.points = points;
	}

	public double getDeviceWidth() {
		return deviceWidth;
	}


	public void setDeviceWidth(double deviceWidth) {
		this.deviceWidth = deviceWidth;
	}

	public double getDeviceHeight() {
		return deviceHeight;
	}

	public void setDeviceHeight(double deviceHeight) {
		this.deviceHeight = deviceHeight;
	}

}
