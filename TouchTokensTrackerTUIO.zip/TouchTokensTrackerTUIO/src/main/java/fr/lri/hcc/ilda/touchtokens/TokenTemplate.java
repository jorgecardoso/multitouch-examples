package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.geom.GeneralPath;
import java.util.ArrayList;

public class TokenTemplate extends MultiTouchInput {

	protected String tokenID;

	protected double recognitionDistance;
	protected double orientation;

	protected TouchPoint center;
	protected GeneralPath contourShape;

	protected TokenTemplate originalGeometryTemplate;

	public TokenTemplate(ArrayList<TouchPoint> points, String tokenID, TouchPoint center) {
		super(points);
		this.points = points;
		this.tokenID = tokenID;
		this.center = center;
		this.orientation = 0;
		this.recognitionDistance = 0;
	}

	public String toString() {
		String points = "";
		for (TouchPoint pt : this.points) {
			points += "("+pt.getX()+","+pt.getY()+")";
		}
		points += "";
		return tokenID+" ["+points+"]";
	}

	public ArrayList<TouchPoint> getPoints() {
		return points;
	}

	public void setPoints(ArrayList<TouchPoint> points) {
		this.points = points;
	}

	public String getTokenID() {
		return tokenID;
	}

	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}

	public double getRecognitionDistance() {
		return recognitionDistance;
	}

	public void setRecognitionDistance(double recognitionDistance) {
		this.recognitionDistance = recognitionDistance;
	}

	public TouchPoint getCenter() {
		return center;
	}

	public void setCenter(TouchPoint center) {
		this.center = center;
	}

	public TokenTemplate getOriginalGeometryTemplate() {
		return originalGeometryTemplate;
	}

	public void setOriginalGeometryTemplate(TokenTemplate originalGeometryTemplate) {
		this.originalGeometryTemplate = originalGeometryTemplate;
	}

	public GeneralPath getContourShape() {
		return contourShape;
	}

	public void setContourShape(GeneralPath contourShape) {
		this.contourShape = contourShape;
	}

	public double getOrientation() {
		return orientation;
	}

	public void setOrientation(double orientation) {
		this.orientation = orientation;
	}

}
