package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.File;

import javax.swing.JFrame;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;

public class Test {

	public static void main(String[] args) {
		Options options = new Options();
		CmdLineParser parser = new CmdLineParser(options);
		try {
			parser.parseArgument(args);
		} catch(CmdLineException ex){
			System.err.println(ex.getMessage());
			parser.printUsage(System.err);
			return;
		}
		System.out.println("--help for command line options");

		// Physical dimensions of macbook pro touchpad (105, 77)
		// Physical dimensions of Samsung tablet (217, 136)
		// Physical dimensions of iPad (198, 148)
		double inputWidth = options.inputWidth; // in mm
		double inputHeight = options.inputHeight; // in mm
		int tuioPort = options.tuioPort;
		String output = options.output;
		String templates = options.templates;

		System.out.println("physical size of tactile surface: "+inputWidth+"mm, "+inputHeight+"mm");
		System.out.println("listening tuio on port: "+tuioPort);

		TouchTokenRecognizer recognizer = new TouchTokenRecognizer(new File(templates));
		TUIOManager tuioManager = new TUIOManager(recognizer, tuioPort, inputWidth, inputHeight);

		if(output.compareTo("canvas") == 0) {
			JFrame frame = new JFrame();
			// create a window that is half screen width and half screen height
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			TestCanvas canvas = new TestCanvas(options.canvasWidth, options.canvasHeight);
			frame.setUndecorated(true);
			frame.setLocation(screenSize.width/2 - options.canvasWidth/2, screenSize.height/2 - options.canvasHeight/2);
			tuioManager.addTokenListener(canvas);
			frame.getContentPane().add(canvas);
			if (options.fullscreen &&
					GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().isFullScreenSupported()){
				GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().setFullScreenWindow(frame);
			} else {
				frame.pack();
			}
			frame.setVisible(true);
		} else if(output.compareTo("console") == 0) {
			TestConsole console = new TestConsole();
			tuioManager.addTokenListener(console);
		} else {
			System.out.println("Unknown output type "+output+" (should be -output canvas or -output console)");
		}

	}

}
