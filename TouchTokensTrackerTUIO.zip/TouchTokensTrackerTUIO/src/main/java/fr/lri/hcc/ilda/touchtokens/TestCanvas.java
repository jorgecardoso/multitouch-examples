package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JPanel;

public class TestCanvas extends JPanel implements TokenListener {

	private static final long serialVersionUID = 3031935397961635020L;

	protected static double SCREEN_RES = -1; // px.mm-1

	protected DecimalFormat df = new DecimalFormat("0.000");

	protected TokenEvent event = null;
	protected String tokenID = null;

	protected float outlineStroke = 1f;

	private Font font = new Font("Arial", Font.PLAIN, 60);

	public TestCanvas(int width, int height) {
		super();
		setPreferredSize(new Dimension(width, height));
		int pixelsPerInch = Toolkit.getDefaultToolkit().getScreenResolution();
		SCREEN_RES = pixelsPerInch / 25.4; // pixels per mm
	}

	public void tokenDown(TokenEvent event) {
		tokenID = event.getTokenID();
		this.event = event;
		repaint();
	}

	public void tokenMoved(TokenEvent event) {
		this.event = event;
		repaint();
	}

	public void tokenUp(TokenEvent event) {
		tokenID = null;
		this.event = event;
		repaint();
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (tokenID == null) {
			return;
		}
		Graphics2D g2d = (Graphics2D) g;
		RenderingHints rh = new RenderingHints(
				RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g2d.setRenderingHints(rh);

		g2d.setTransform(new AffineTransform());

		TouchPoint point = null;
		double dx = 0;
		double dy = 0;
		double dxInMM = 0;
		double dyInMM = 0;
		double dxInWindow = 0;
		double dyInWindow = 0;

		// NOTCH POINTS complemented (missing points from notch points at down)
		ArrayList<TouchPoint> notchPoints = new ArrayList<TouchPoint>();
		for (Iterator<TouchPoint> iterator = event.getNotchPoints().iterator(); iterator.hasNext();) {
			TouchPoint touchPoint = iterator.next();
			if (touchPoint != null) {
				notchPoints.add(touchPoint);
			} else {
				System.err.println("Unexpected: a token point is missing.");
			}
		}
		TouchPoint tokenCenter = event.getTokenCenter();
		g2d.setColor(Color.ORANGE);
		g2d.drawOval((int) (tokenCenter.x * getWidth() - 5),
				(int) (tokenCenter.y * getHeight() - 5), 10, 10);
		int index = 0;
		for (Iterator<TouchPoint> iterator = notchPoints.iterator(); iterator.hasNext();) {
			point = iterator.next();
			dx = point.x - tokenCenter.x;
			dy = point.y - tokenCenter.y;
			dxInMM = dx * event.getDeviceWidth();
			dyInMM = dy * event.getDeviceHeight();
			dxInWindow = dxInMM * SCREEN_RES;
			dyInWindow = dyInMM * SCREEN_RES;
			if(index == 0) {
				g2d.setColor(Color.RED);
			} else if(index == 1) {
				g2d.setColor(Color.GREEN);
			} else if(index == 2) {
				g2d.setColor(Color.BLUE);
			} else {
				g2d.setColor(Color.LIGHT_GRAY);
			}
			g2d.drawOval(
					(int) (tokenCenter.x * getWidth() + dxInWindow - 5),
					(int) (tokenCenter.y * getHeight() + dyInWindow - 5),
					10, 10);
			index++;
		}

		// TOKEN OUTLINE
		double tokenRelOrientation = event.getTokenRelOrientation();
		double tokenAbsOrientation = event.getTokenInitOrientation() + tokenRelOrientation;
		g2d.setColor(Color.LIGHT_GRAY);
		AffineTransform xForm = new AffineTransform();
		xForm.translate((int)(tokenCenter.x * getWidth()), (int)(tokenCenter.y * getHeight()));
		xForm.rotate(-tokenAbsOrientation);
		xForm.scale(SCREEN_RES, SCREEN_RES); 
		g2d.setStroke(new BasicStroke((float)(outlineStroke/SCREEN_RES)));
		g2d.setTransform(xForm);
		g2d.draw(event.getUntransformedTemplate().getContourShape());
		g2d.setTransform(new AffineTransform());
		g2d.setStroke(new BasicStroke(1));

		// TOUCH POINTS
		ArrayList<TouchPoint> ptsTouch = new ArrayList<TouchPoint>();
		for (Iterator<TouchPoint> iterator = event.getTouchPoints().iterator(); iterator.hasNext();) {
			TouchPoint touchPoint = iterator.next();
			ptsTouch.add(touchPoint);
		}
		index = 0;
		for (Iterator<TouchPoint> iterator = ptsTouch.iterator(); iterator.hasNext();) {
			point = iterator.next();
			if(point != null) {
				dx = point.x - tokenCenter.x;
				dy = point.y - tokenCenter.y;
				dxInMM = dx * event.getDeviceWidth();
				dyInMM = dy * event.getDeviceHeight();
				dxInWindow = dxInMM * SCREEN_RES;
				dyInWindow = dyInMM * SCREEN_RES;
				if(index == 0) {
					g2d.setColor(Color.RED);
				} else if(index == 1) {
					g2d.setColor(Color.GREEN);
				} else if(index == 2) {
					g2d.setColor(Color.BLUE);
				} else {
					g2d.setColor(Color.LIGHT_GRAY);
				}
				g2d.fillOval((int)(tokenCenter.x * getWidth() + dxInWindow - 5),
						(int)(tokenCenter.y * getHeight() + dyInWindow - 5), 10, 10);
			}
			index++;
		}

		g2d.setColor(Color.BLACK);
		setFont(font);
		FontMetrics fm = g.getFontMetrics();
		String textTokenID = tokenID;
		String textLocation = "(" + (int) (tokenCenter.x * getWidth()) + ", "
				+ (int) (tokenCenter.y * getHeight()) + ")";
		String textOrientation = "abs="+df.format(tokenAbsOrientation)+", rel="+df.format(tokenRelOrientation);
		Rectangle2D boundsTextLocation = fm.getStringBounds(textLocation, g);
		Rectangle2D boundsTextOrientation = fm.getStringBounds(textOrientation, g);
		g2d.drawString(textTokenID, 10, (int) (getHeight() - 10
				- boundsTextOrientation.getHeight() - 10 - boundsTextLocation.getHeight() - 10));
		g2d.drawString(textLocation, 10,
				(int) (getHeight() - 10 - boundsTextOrientation.getHeight() - 10));
		g2d.drawString(textOrientation, 10,
				(int) (getHeight() - 10));
	}

}
