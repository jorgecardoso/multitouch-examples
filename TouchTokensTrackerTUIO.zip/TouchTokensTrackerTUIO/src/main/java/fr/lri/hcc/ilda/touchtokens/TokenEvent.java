package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.util.ArrayList;
import java.util.EventObject;

public class TokenEvent extends EventObject {

	private static final long serialVersionUID = 3067543063371826506L;

	protected String tokenID;

	protected ArrayList<TouchPoint> touchPoints; // normalized in [0,1]
	protected ArrayList<TouchPoint> notchPoints; // normalized in [0,1]

	protected double deviceWidth; // size of the physical input surface in mm
	protected double deviceHeight;

	protected TokenTemplate transformedTemplate; // in mms
	protected TokenTemplate untransformedTemplate; // in mms

	public TokenEvent(Object source) {
		super(source);
	}

	public TokenEvent(Object source, String tokenID,
			ArrayList<TouchPoint> touchPoints,
			ArrayList<TouchPoint> tokenPoints,
			double deviceWidth,
			double deviceHeight,
			TokenTemplate transformedTemplate,
			TokenTemplate untransformedTemplate) {
		super(source);
		this.tokenID = tokenID;
		this.touchPoints = touchPoints;
		this.notchPoints = tokenPoints;
		this.deviceWidth = deviceWidth;
		this.deviceHeight = deviceHeight;
		this.transformedTemplate = transformedTemplate;
		this.untransformedTemplate = untransformedTemplate;
	}

	public String getTokenID() {
		return tokenID;
	}

	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}

	public ArrayList<TouchPoint> getTouchPoints() {
		return touchPoints;
	}

	public void setTouchPoints(ArrayList<TouchPoint> points) {
		this.touchPoints = points;
	}

	public double getDeviceWidth() {
		return deviceWidth;
	}

	public void setDeviceWidth(double deviceWidth) {
		this.deviceWidth = deviceWidth;
	}

	public double getDeviceHeight() {
		return deviceHeight;
	}

	public void setDeviceHeight(double deviceHeight) {
		this.deviceHeight = deviceHeight;
	}

	public ArrayList<TouchPoint> getNotchPoints() {
		return notchPoints;
	}

	public void setNotchPoints(ArrayList<TouchPoint> templatePoints) {
		this.notchPoints = templatePoints;
	}

	public TokenTemplate getTransformedTemplate() {
		return transformedTemplate;
	}

	public TokenTemplate getUntransformedTemplate() {
		return untransformedTemplate;
	}

	public double getTokenInitOrientation() {
		return transformedTemplate.getOrientation();
	}

	public double getTokenRelOrientation() {
		TouchPoint transformedTemplateCenter = transformedTemplate.getCenter();
		TouchPoint transformedTemplate1 = transformedTemplate.getPoints().get(0);
		TouchPoint vTransformedTemplate = new TouchPoint(
				transformedTemplate1.x - transformedTemplateCenter.x,
				transformedTemplate1.y - transformedTemplateCenter.y);
		TouchPoint currentCenter = getTokenCenter();
		currentCenter = new TouchPoint(currentCenter.x*deviceWidth, currentCenter.y*deviceHeight);
		TouchPoint current1 = notchPoints.get(0);
		current1 = new TouchPoint(current1.x*deviceWidth, current1.y*deviceHeight);
		TouchPoint vCurrent = new TouchPoint(
				current1.x - currentCenter.x,
				current1.y - currentCenter.y);
		double angle = TouchTokenRecognizer.angleBetweenVectors(vCurrent, vTransformedTemplate);
		return angle;
	}

	/**
	 * @return the location of the token center normalized in [0,1] in the input device frame of reference
	 */
	public TouchPoint getTokenCenter() {
		TouchPoint centerTemplate = new TouchPoint(transformedTemplate.getCenter().x, transformedTemplate.getCenter().y);
		TouchPoint pt1Template = new TouchPoint(transformedTemplate.getPoints().get(0).x, transformedTemplate.getPoints().get(0).y);
		TouchPoint pt2Template = new TouchPoint(transformedTemplate.getPoints().get(1).x, transformedTemplate.getPoints().get(1).y);
		TouchPoint v1CenterTemplate = new TouchPoint(centerTemplate.x - pt1Template.x, centerTemplate.y - pt1Template.y);
		TouchPoint v12Template = new TouchPoint(pt2Template.x - pt1Template.x, pt2Template.y - pt1Template.y);

		double angle21Center = TouchTokenRecognizer.angleBetweenVectors(v12Template, v1CenterTemplate);

		TouchPoint pt1Token = notchPoints.get(0);
		pt1Token = new TouchPoint(pt1Token.x*deviceWidth, pt1Token.y*deviceHeight);
		TouchPoint pt2Token = notchPoints.get(1);
		pt2Token = new TouchPoint(pt2Token.x*deviceWidth, pt2Token.y*deviceHeight);
		TouchPoint v12Token = new TouchPoint(pt2Token.x - pt1Token.x, pt2Token.y - pt1Token.y);
		double x12Token = TouchTokenRecognizer.angleBetweenVectors(new TouchPoint(1, 0), v12Token);

		double length1Center =
				Math.sqrt((centerTemplate.x - pt1Template.x) * (centerTemplate.x - pt1Template.x) +
						(centerTemplate.y - pt1Template.y) * (centerTemplate.y - pt1Template.y));

		TouchPoint centerToken = new TouchPoint(length1Center, 0);
		centerToken.setLocation(centerToken.x + pt1Token.getX(), centerToken.y + pt1Token.getY());
		double angle = x12Token + angle21Center;
		TouchTokenRecognizer.rotateBy(centerToken, pt1Token, angle, centerToken);
		centerToken.setLocation(centerToken.x/deviceWidth, centerToken.y/deviceHeight);
		return centerToken;
	}

	public void setTemplate(TokenTemplate template) {
		this.transformedTemplate = template;
	}

}
