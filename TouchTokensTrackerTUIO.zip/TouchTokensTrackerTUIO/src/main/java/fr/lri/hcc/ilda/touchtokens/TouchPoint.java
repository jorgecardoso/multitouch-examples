package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

public class TouchPoint {

	public double x;
	public double y;

	public TouchPoint() { }

	public TouchPoint(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}

	public String toString() {
		return "["+x+", "+y+"]";
	}

	public double distance(TouchPoint p) {
		return Math.sqrt((p.x - x) * (p.x - x) + (p.y - y) * (p.y - y));
	}

	public void setLocation(double x, double y) {
		this.x = x;
		this.y = y;
	}

}
