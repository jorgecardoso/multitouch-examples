package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.util.ArrayList;
import java.util.List;

import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.Option;

public class Options {

	@Option(name = "-fs", aliases = {"--fullscreen"}, usage = "full-screen")
    public boolean fullscreen = false;

    @Option(name = "-tuio", usage = "TUIO port")
    public int tuioPort = 3333;

    @Option(name = "-inputWidth", usage = "width of tactile surface in mm")
    public int inputWidth = 198; // 105; // 720;

    @Option(name = "-inputHeight", usage = "height of tactile surface in mm")
    public int inputHeight = 148; // 75; // 396

    // trackpad: 105x75
    // tablet Samsung: 198x148
    // 3M screen: 720x396

    @Option(name = "-output", usage = "canvas or console")
    public String output = "canvas";

    @Option(name = "-canvasWidth", usage = "canvas width in pixels")
    public int canvasWidth = 792; // 800; // 1920;

    @Option(name = "-canvasHeight", usage = "canvas width in pixels")
    public int canvasHeight = 592; // 600; //1080;

    @Option(name = "-templates", usage = "path for template files")
    public String templates = "templates/templates.txt";

    @Argument
    List<String> arguments = new ArrayList<String>();

}
