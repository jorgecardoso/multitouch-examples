package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.Timer;

import TUIO.TuioClient;
import TUIO.TuioCursor;
import TUIO.TuioListener;
import TUIO.TuioObject;
import TUIO.TuioTime;

public class TUIOManager implements TuioListener, ActionListener {

	protected TouchTokenRecognizer recognizer;
	protected String tokenDown = null;
	protected ArrayList<TokenListener> listeners;

	protected double inputWidth = -1;
	protected double inputHeight = -1;

	protected static TouchPoint[] FINGERS_LOCATION = new TouchPoint[10];
	protected static TouchPoint[] FINGERS_LOCATION_AT_TIMER_START_TIME = new TouchPoint[10];

	protected int dwellDuration = 200; // in ms
	protected double dwellTolerance = 3; // in mm

	protected Timer dwellTimer;
	protected long dwellStartTime = -1;
	protected long lastUpdateTime = -1;

	protected boolean debug = false;

	protected ArrayList<Integer> indices = new ArrayList<Integer>();

	protected ArrayList<TouchPoint> notchPointsAtDown;
	protected TokenTemplate currentTemplate;

	public TUIOManager(TouchTokenRecognizer recognizer, int tuioPort, double inputWidth, double inputHeight) {
		this.recognizer = recognizer;
		this.inputWidth = inputWidth;
		this.inputHeight = inputHeight;

		listeners = new ArrayList<TokenListener>();

		dwellTimer = new Timer(25, this);
		dwellTimer.setRepeats(true);
		dwellTimer.start();

		TuioClient tuioClient = new TuioClient(tuioPort);
		if(tuioClient != null) tuioClient.addTuioListener(this);
		tuioClient.connect();
	}

	public void addTokenListener(TokenListener listener) {
		listeners.add(listener);
	}

	public void removeTokenListener(TokenListener listener) {
		listeners.remove(listener);
	}

	protected void fireTokenDown(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight, TokenTemplate transformedTemplate) {
		notchPointsAtDown = new ArrayList<TouchPoint>();
		for (TouchPoint touchPoint : transformedTemplate.getPoints()) {
			notchPointsAtDown.add(new TouchPoint(touchPoint.x/deviceWidth, touchPoint.y/deviceHeight));
		}

		ArrayList<TouchPoint> tokenPoints = new ArrayList<TouchPoint>(points);
		TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, tokenPoints, deviceWidth, deviceHeight, transformedTemplate, recognizer.getTemplate(transformedTemplate.getTokenID()));
		for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
			TokenListener tokenListener = iterator.next();
			tokenListener.tokenDown(tokenEvent);
		}
	}
	
	protected void complementNotchPoints(ArrayList<TouchPoint> notchPointsAtDown, ArrayList<TouchPoint> touchPoints, double deviceWidth, double deviceHeight) {
        int missingIndex = -1;
        TouchPoint notchDown1 = null;
        TouchPoint notch1 = null;
        TouchPoint notchDown2 = null;
        TouchPoint notch2 = null;
        TouchPoint notchDown3 = null;
        for (int i = 0; i < touchPoints.size(); i++) {
            if(touchPoints.get(i) == null) {
                missingIndex = i;
                notchDown3 = notchPointsAtDown.get(i);
                notchDown3 = new TouchPoint(notchDown3.x*deviceWidth, notchDown3.y*deviceHeight);
            } else {
                if(notchDown1 == null) {
                    notchDown1 = notchPointsAtDown.get(i);
                    notchDown1 = new TouchPoint(notchDown1.x*deviceWidth, notchDown1.y*deviceHeight);
                    notch1 = touchPoints.get(i);
                    notch1 = new TouchPoint(notch1.x*deviceWidth, notch1.y*deviceHeight);
                } else {
                    notchDown2 = notchPointsAtDown.get(i);
                    notchDown2 = new TouchPoint(notchDown2.x*deviceWidth, notchDown2.y*deviceHeight);
                    notch2 = touchPoints.get(i);
                    notch2 = new TouchPoint(notch2.x*deviceWidth, notch2.y*deviceHeight);
                }
            }
        }
        if(missingIndex == -1) {
            return;
        } else {
            TouchPoint vNotchesDown13 = new TouchPoint(notchDown3.x - notchDown1.x, notchDown3.y - notchDown1.y);
            TouchPoint vNotchesDown12 = new TouchPoint(notchDown2.x - notchDown1.x, notchDown2.y - notchDown1.y);
            double angleNotchesDown213 = TouchTokenRecognizer.angleBetweenVectors(vNotchesDown12, vNotchesDown13);

            TouchPoint vNotches12 = new TouchPoint(notch2.x - notch1.x, notch2.y - notch1.y);
            double angleNotchesx12 = TouchTokenRecognizer.angleBetweenVectors(new TouchPoint(1, 0), vNotches12);

            double lengthNotchesDown13 =
                    Math.sqrt((notchDown3.x - notchDown1.x) * (notchDown3.x - notchDown1.x) +
                            (notchDown3.y - notchDown1.y) * (notchDown3.y - notchDown1.y));

            TouchPoint notch3 = new TouchPoint(lengthNotchesDown13, 0);
            notch3.setLocation(notch3.x + notch1.getX(), notch3.y + notch1.getY());
            double angle = angleNotchesx12 + angleNotchesDown213;
            TouchTokenRecognizer.rotateBy(notch3, notch1, angle, notch3);
            notch3.setLocation(notch3.x / deviceWidth, notch3.y / deviceHeight);
            touchPoints.set(missingIndex, notch3);
        }
    }

	protected void fireTokenMoved(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight, TokenTemplate transformedTemplate) {
		ArrayList<TouchPoint> tokenPoints = new ArrayList<TouchPoint>();
		int pointsCount = 0;
		for (Iterator<TouchPoint> iterator = points.iterator(); iterator.hasNext();) {
			TouchPoint touchPoint = iterator.next();
			tokenPoints.add(touchPoint);
			if(touchPoint != null) {
				pointsCount++;
			}
		}
		if(pointsCount == 1) {
			tokenUp();
		}
		if(pointsCount == 2) {
			complementNotchPoints(notchPointsAtDown, tokenPoints, deviceWidth, deviceHeight);
		}
		if(pointsCount == 2 || pointsCount == 3) {
			TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, tokenPoints, deviceWidth, deviceHeight, transformedTemplate, recognizer.getTemplate(transformedTemplate.getTokenID()));
			for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
				TokenListener tokenListener = iterator.next();
				tokenListener.tokenMoved(tokenEvent);
			}
		}
	}

	protected void fireTokenUp(String tokenID, ArrayList<TouchPoint> points, double deviceWidth, double deviceHeight, TokenTemplate transformedTemplate) {
		TokenEvent tokenEvent = new TokenEvent(this, tokenID, points, points, deviceWidth, deviceHeight, transformedTemplate, recognizer.getTemplate(transformedTemplate.getTokenID()));
		for (Iterator<TokenListener> iterator = listeners.iterator(); iterator.hasNext();) {
			TokenListener tokenListener = iterator.next();
			tokenListener.tokenUp(tokenEvent);
		}
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == dwellTimer) {
			if(dwellStartTime == -1) {
				return;
			}
			if(tokenDown != null) {
				return;
			}
			long currentTime = System.currentTimeMillis();
			if((currentTime - dwellStartTime) >= dwellDuration && (lastUpdateTime - dwellStartTime) < dwellDuration) {
				ArrayList<TouchPoint> inputInMms = new ArrayList<TouchPoint>(); // the recognizer stores templates in mm
				ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
				indices.clear();
				for (int i = 0; i < FINGERS_LOCATION.length; i++) {
					if(FINGERS_LOCATION[i] != null) {
						indices.add(i);
						inputInMms.add(new TouchPoint(FINGERS_LOCATION[i].x * inputWidth, FINGERS_LOCATION[i].y * inputHeight));
						inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
					}
				}
				if(debug) {
					System.out.println("input: "+inputInMms);
				}
				currentTemplate = recognizer.recognize(inputInMms);

				if(debug) {
					System.out.println("recognized as: "+currentTemplate);
				}
				if(currentTemplate != null) {
					tokenDown = currentTemplate.getTokenID();
					fireTokenDown(tokenDown, inputIn01, inputWidth, inputHeight, currentTemplate);
				}
			}
			lastUpdateTime = System.currentTimeMillis();
		}
	}

	public void addTuioObject(TuioObject arg0) { }

	public void removeTuioObject(TuioObject arg0) { }

	public void updateTuioObject(TuioObject arg0) { }

	public void refresh(TuioTime arg0) { }

	public void addTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();
		FINGERS_LOCATION[cursorID] = new TouchPoint(arg0.getX(), arg0.getY());
		if(debug) {
			System.out.println("+ tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
		}
		dwellStartTime = System.currentTimeMillis();
	}

	protected void tokenUp() {
		if(tokenDown != null) {
			dwellStartTime = -1;
			ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
			for (int i = 0; i < FINGERS_LOCATION.length; i++) {
				if(FINGERS_LOCATION[i] != null) {
					inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
				} else if(indices.contains(i)) {
					inputIn01.add(null);
				}
			}
			fireTokenUp(tokenDown, inputIn01, inputWidth, inputHeight, currentTemplate);
			tokenDown = null;
		}
	}

	public void removeTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();
		int fingerCount = 0;
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			if(FINGERS_LOCATION[i] != null) {
				fingerCount++;
			}
		}
		if(fingerCount == 1) {
			tokenUp();
		} else {
			dwellStartTime = System.currentTimeMillis();
		}
		FINGERS_LOCATION[cursorID] = null;
		if(debug) {
			System.out.println("- tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
		}
	}

	public void updateTuioCursor(TuioCursor arg0) {
		int cursorID = arg0.getCursorID();

		FINGERS_LOCATION[cursorID] = new TouchPoint(arg0.getX(), arg0.getY());

		if(debug) {
			System.out.println("~ tuio cursor "+arg0.getCursorID()+": ("+arg0.getX()+", "+arg0.getY()+")");
		}

		// sometimes, MT events are not delivered in the right order, avoid null exception:
		if(FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID] == null) {
			FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID] = FINGERS_LOCATION[cursorID];
		}

		TouchPoint pointNow = new TouchPoint(FINGERS_LOCATION[cursorID].x * inputWidth, FINGERS_LOCATION[cursorID].y * inputHeight);
		TouchPoint pointAtTimerStartTime = new TouchPoint(FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID].x * inputWidth, FINGERS_LOCATION_AT_TIMER_START_TIME[cursorID].y * inputHeight);

		double distance = pointNow.distance(pointAtTimerStartTime);

		boolean dwelling = distance < dwellTolerance;
		if(!dwelling) {
			for (int i = 0; i < FINGERS_LOCATION.length; i++) {
				FINGERS_LOCATION_AT_TIMER_START_TIME[i] = FINGERS_LOCATION[i];
			}
			dwellStartTime = System.currentTimeMillis();
		}

		ArrayList<TouchPoint> inputIn01 = new ArrayList<TouchPoint>();
		for (int i = 0; i < FINGERS_LOCATION.length; i++) {
			if(FINGERS_LOCATION[i] != null) {
				inputIn01.add(new TouchPoint(FINGERS_LOCATION[i].x, FINGERS_LOCATION[i].y));
			} else if(indices.contains(i)) {
				inputIn01.add(null);
			}
		}
		if(tokenDown != null) {
			fireTokenMoved(tokenDown, inputIn01, inputWidth, inputHeight, currentTemplate);
		}
	}

	public int getDwellDuration() {
		return dwellDuration;
	}

	public void setDwellDuration(int dwellDuration) {
		this.dwellDuration = dwellDuration;
	}

	public double getDwellTolerance() {
		return dwellTolerance;
	}

	public void setDwellTolerance(double dwellTolerance) {
		this.dwellTolerance = dwellTolerance;
	}

	public double getInputWidth() {
		return inputWidth;
	}

	public void setInputWidth(double inputWidth) {
		this.inputWidth = inputWidth;
	}

	public double getInputHeight() {
		return inputHeight;
	}

	public void setInputHeight(double inputHeight) {
		this.inputHeight = inputHeight;
	}

}
