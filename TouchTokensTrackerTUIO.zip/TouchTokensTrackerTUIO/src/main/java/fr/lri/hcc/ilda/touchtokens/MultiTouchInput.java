package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.util.ArrayList;

public class MultiTouchInput {

	protected ArrayList<TouchPoint> points;

	public MultiTouchInput(ArrayList<TouchPoint> points) {
		super();
		this.points = points;
	}

	public ArrayList<TouchPoint> getPoints() {
		return points;
	}

	public String toString() {
		String points = "[";
		for (TouchPoint pt : this.points) {
			points += "("+(int)pt.getX()+","+(int)pt.getY()+")";
		}
		points += "]";
		return points;
	}

}
