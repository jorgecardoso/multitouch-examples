package fr.lri.hcc.ilda.touchtokens;

/*
 *   Authors: Caroline Appert (caroline.appert@lri.fr)
 *   Copyright (c) Univ. Paris-Sud XI, 2016. All Rights Reserved
 *   Licensed under the GNU LGPL. For full terms see the file COPYING.
*/

import java.io.Console;
import java.text.DecimalFormat;

public class TestConsole implements TokenListener {

	protected DecimalFormat df = new DecimalFormat("0.0000");

	protected boolean end = false;

	public TestConsole() {
		final Console c = System.console();
        if (c == null) {
            System.err.println("No console.");
            System.exit(1);
        }
        System.out.println("Type quit to quit the program.");
        Runnable readConsole = new Runnable() {
        	public void run() {
        		while(!end) {
        			try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
        			String line = c.readLine();
        			end = line.endsWith("quit");
        			if(end) {
        				System.exit(1);
        			}
        		}

        	}
        };
        (new Thread(readConsole)).start();
	}


	protected String eventToString(TokenEvent event) {
		TouchPoint tokenLocation = event.getTokenCenter();
		double tokenRelOrientation = event.getTokenRelOrientation();
		double tokenAbsOrientation = event.getTokenInitOrientation() + tokenRelOrientation;
		String textOrientation = "[abs] "+df.format(tokenAbsOrientation)+"[rel] "+df.format(tokenRelOrientation);
		return event.tokenID+" location=("+df.format(tokenLocation.x)+", "+df.format(tokenLocation.y)+") orientation=("+textOrientation+")";
	}

	public void tokenDown(TokenEvent event) {
		System.out.println("+ "+eventToString(event));
	}

	public void tokenMoved(TokenEvent event) {
		System.out.println("~ "+eventToString(event));
	}

	public void tokenUp(TokenEvent event) {
		System.out.println("- "+event.tokenID);
	}

}
