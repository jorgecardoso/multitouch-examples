#!/bin/sh

java -jar target/touchtokensTUIO-0.0.2.jar "$@"
